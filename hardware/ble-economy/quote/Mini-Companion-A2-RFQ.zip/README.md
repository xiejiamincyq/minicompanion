# Mini Companion BLE-A2 两台整机询价

请报两台免焊交付样机的含税、含运价和交期。按 5 片裸板、贴装其中 2 片计算，余下 3 片空板随货。每台含微雪 2 英寸彩屏控制核心、单面贴装的定制按键电源小板、带保护的 2000 mAh 电池、贴在电芯表面的独立温感探头、预制线束、配套墙充及维护数据线、外壳和逐机测试。该文件用于报价。

1. **PCB 与贴片**　[光绘和钻孔 ZIP](manufacturing/a2-gerber-drill.zip)、[嘉立创 BOM](sourcing/BOM_JLC_顶面.csv)、[顶面贴装坐标](manufacturing/top-position-jlc.csv)，请优先按经济型计价。[坐标与方向说明](manufacturing/README.md) · [顶面装配图](verification/a2_top_assembly.pdf) · [专用封装与厂图依据](project/PCB设计说明.md)
2. **采购与代装**　请核微雪无触摸核心 SKU 30306 的 V2 实物、预焊排针、配套 5V 直出电源、三类线束和全部费用。[逐针接线、供货及报价范围](sourcing/外部询价与免焊线束要求.md)
3. **打印与装箱**　两套共打印 12 件，前壳 2、后盖 2、圆按帽 6、侧拨帽 2。[STL 文件](mechanical/stl/) · [开孔、五金、贴温感与总装](mechanical/装配.md)
4. **测试**　请分别报装配和验证工费，标明是否能完成两台探头冷、热禁充、充电停机、USB 烧录和双机/手机 BLE。请列出未覆盖的工序。[逐机记录表](整机验收.md) · [电路图 PDF](verification/a2_schematic.pdf) · [电气设计及验收条件](design/电气设计与验收.md)
5. **工程源文件**　[KiCad 10 工程](project/mini_companion_a2.kicad_pro)、[原理图](project/mini_companion_a2.kicad_sch)、[PCB](project/mini_companion_a2.kicad_pcb) 随包提供。文件指纹见根目录 `manifest.json`。

报价优先使用附件的精确型号。在回复中逐项列出需替换的器件、加工条件、供应商垫料、可能的附加收费和运输方式。未经另行确认，请勿开工。
